package com.board.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TestController {
	
	// http://localhost:9090/ root
	@RequestMapping("/")
	public  String  home() {
		return "home";    
		  // /WEB-INF/views/  + home + .jsp  
		  // src/main/webapp/WEB-INF/views/home.jsp  
	}
	
	// http://localhost:9090/test
	@RequestMapping("/test")
	@ResponseBody
	public String test() {
		return "<h2>Hello SpringBoot!!!</h2>";
	}
	
	@RequestMapping("/GalInfo")
	public  String   galInfo() {
		return  "gal";
	}
	
	@RequestMapping("/GetGalInfo")
	@ResponseBody
	public  String   getGalInfo(String numOfRows, String pageNo) 
			throws IOException {
		
		String  serviceKey = "HPG%2FiUcz%2Ft%2FQ8HAFjrKL9sP2JYkLOIIgbnEzvj9enzRYy%2BjXWDidxABqUgD85CcU%2FUhqdtU2SPY%2Btq97nfbRxw%3D%3D";
		String  dataUrl    = "http://apis.data.go.kr/6260000/fbusangmgtourinfo/getgmgtourinfo";
		
		StringBuilder urlBuilder = new StringBuilder( dataUrl ); /*URL*/
		urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=" + serviceKey); /*Service Key*/
		urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode(numOfRows, "UTF-8")); /*검색건수*/
		urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode(pageNo, "UTF-8")); /*페이지 번호*/
		urlBuilder.append("&" + URLEncoder.encode("resultType","UTF-8") + "=" + URLEncoder.encode("json", "UTF-8")); /*JSON방식으로 호출 시 파라미 resultType=json 입력*/
		URL url = new URL(urlBuilder.toString());
		
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		System.out.println("Response code: " + conn.getResponseCode());
		
		BufferedReader rd;
		if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		
		StringBuilder sb = new StringBuilder();
		String       line;
		while ((line = rd.readLine()) != null) {
			sb.append(line);
		}
		
		rd.close();
		conn.disconnect();
		System.out.println(sb.toString());
		
		return sb.toString();
	}

}
	






