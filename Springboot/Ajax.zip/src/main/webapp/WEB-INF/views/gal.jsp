<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

<link rel="icon" type="image/ico" href="/img/favicon.ico" />
<link rel="stylesheet"  href="/css/common.css" /> 

<style>
   ul { 
      margin: 20px; padding: 10px; width: 450px;
      border: 1px solid blue;
      border-radius : 10px;
      list-style-type: none;      
      float:left; 
   }

</style>

</head>
<body>
  <main>
   <h2>갈맷길 관광정보</h2>
   <a href="/">Home</a>
   <hr>
   <button id="btnGet">Get Info</button>
   <div  id="galinfo"></div>
   
  </main>
  
  <script>
 
  
  const  btnGetEl  = document.querySelector('#btnGet')
  const  galinfoEl = document.querySelector('#galinfo') 
  btnGetEl.onclick = function() {
	  // 로컬서버(자바소스) data 가져오기 - 비동기방식으로
	  // /GetGalInfo?numOfRows=10&pageNo=1
	  let  url = '/GetGalInfo?numOfRows=10&pageNo=1'
	  fetch(url)
	    .then( (resp) => resp.json() )
	    .then( (data) => {
	    	console.log(data)
	    	//console.log(data.response.body.items)
	    	let html = '' 
	    	let arr = data.response.body.items.item
	    	console.log(arr)
	    	for(let i=0; i < arr.length; i++ ) {
	  		   html +=  "<ul>"
	  		   html +=  "<li>" + arr[i].uc_seq + "</li>"
	  		   html +=  "<li>" + arr[i].name + "</li>"
	  		   html +=  "<li>" + arr[i].place + "</li>"
	  		   html +=  "<li>" + arr[i].title + "</li>"
	  		   html +=  "<li>" + arr[i].uc_seq + "</li>"
	  		   html +=  "<li>" + arr[i].main_img_t + "</li>"
	  		   html +=  "</ul>"	  			
	  		}
	    	//alert(html)
	    	galinfoEl.innerHTML = html;
	    	//alert(data)
	    })
	    .catch((error) => {
	    	console.log(error)
	    	alert(error)
	    })
  }
  
  </script>
   
</body>
</html>







