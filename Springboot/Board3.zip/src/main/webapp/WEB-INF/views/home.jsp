<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

<link rel="icon" type="image/ico" href="/img/favicon.ico" />
<link rel="stylesheet"  href="/css/common.css" /> 

</head>
<body>
  <main>
   <h2>Home</h2>
   <a href="/test">Test</a>
   <hr>
   
   <a href="/Menus/List">메뉴 목록</a><br>
   <a href="/Menus/WriteForm">새 메뉴 추가</a><br>
   <hr>
   <a href="/Users/List">사용자 목록</a><br />
   <a href="/Users/WriteForm">새 사용자 추가</a><br />
  </main>
   
</body>
</html>







