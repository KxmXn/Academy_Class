package com.example.loose;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
public class CoffeeMaker {
	
	@Autowired      // type으로 체크(1개만 가능)   
	/*
	@Qualifier("espressoMachine")  
	   // 같은 type 의 component 가 두개 있으면 @Qualifier( 이름) 구분
	   // 옛날 문법 -> 현재는 @Primary 로 처리
	*/
	private  CoffeeMachine  coffeeMachine;
	
	/* 
	public  void setCoffeeMachine( CoffeeMachine coffeeMachine ) {
		this.coffeeMachine  =  coffeeMachine;
	} // @Autowired 로 대체
	*/
	
	@PostConstruct
	public   void    makeCoffee() {		
		System.out.println( coffeeMachine.brew() );
	}
	
}
