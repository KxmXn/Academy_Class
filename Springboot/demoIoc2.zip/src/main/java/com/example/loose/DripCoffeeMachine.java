package com.example.loose;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
// @Primary     // type 이 같은 두 componenet 에 우선 순위를 제공 
             // (dripCoffeeMachine) 이 선택되게 한다 @Qualifier(0 역할
public class DripCoffeeMachine implements CoffeeMachine {

	@Override
	public String brew() {		
		return "드립커피머신으로 커피 추출 하기 ";
	}

}
